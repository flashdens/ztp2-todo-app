# Tydzień 1. (02 - 09 III)
- konfiguracja środowiska programistycznego
- utworzenie pierwszego kontrolera

# Tydzień 2. (10 – 16 III)
- oswojenie się z podejściem TDD
- konfiguracja PHPUnit
- rozwiązanie katy *FizzBuzz* (branch `FizzBuzz`)

# Tydzień 3. (17 – 23 III)
- brak postępów

# Tydzień 4. (24 - 30 III)
 - utworzenie encji Task wraz Fixtures i widokami dla niej
 - konfiguracja paginacji
 - rozpoczęcie tworzenia testów dla TaskController
 
# Tydzień 5. (31 III - 6 IV)
 - konfiguracja warstwy serwisów oraz repozytoriów dla Task - optymalizacja zapytań
 
# Tydzień 6. (7 - 13 IV)
- CRUD dla Task

# Tydzień 7. (14 - 20 IV)
- CRUD dla kategorii
- konfiguracja użytkowników
- porządki w widokach

# Tydzień 8. (21 - 28 IV)
- utworzenie encji Note
- CRUD dla Note

# Tydzień 9. (29 IV - 03 V)
- konfiguracja PHPUnit razem z testową bazą danych
- utworzenie testów dla CategoryService
- porządki w warstwie prezentacji


